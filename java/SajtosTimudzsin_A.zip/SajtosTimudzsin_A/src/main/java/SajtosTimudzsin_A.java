import modell.Modell;
import nezet.SwingNezet;

import javax.swing.*;

public class SajtosTimudzsin_A {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Modell modell = new Modell();

            SwingNezet view = new SwingNezet(modell);
            view.setVisible(true);
        });
    }
}
