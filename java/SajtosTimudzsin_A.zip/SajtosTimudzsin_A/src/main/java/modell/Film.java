package modell;

public class Film {
    private String cim;
    private int megjelenesi_ev;
    private String rendezo;
    private double ertekeles;

    public Film(String cim, int megjelenesi_ev, String rendezo, double ertekeles) {
        this.cim = cim;
        this.megjelenesi_ev = megjelenesi_ev;
        this.rendezo = rendezo;
        this.ertekeles = ertekeles;
    }

    public String getCim() {
        return cim;
    }

    public int getMegjelenesi_ev() {
        return megjelenesi_ev;
    }

    public String getRendezo() {
        return rendezo;
    }

    public double getErtekeles() {
        return ertekeles;
    }
}
