package modell;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Modell {
    public Film film1 = new Film("A remény rabjai", 1994, "Frank Darabont", 9.3);
    public Film film2 = new Film("A keresztapa", 1972, "Francis Fort Copolla", 9.2);
    public Film film3 = new Film("Forrest Gump", 1994, "Robert Zemeckis", 8.8);
    public Film film4 = new Film("Mátrix", 1999, "Lana Wachowski", 8.7);
    public Film film5 = new Film("Gladiátor", 2000, "Ridley Scott", 8.5);

    //private ArrayList<Film> filmek = new ArrayList<>();
    public Film[] filmek = {film1, film2, film3, film4, film5};

    public Modell() {
        this.film1 = film1;
        this.film2 = film2;
        this.film3 = film3;
        this.film4 = film4;
        this.film5 = film5;
        this.filmek = filmek;
    }

    public Modell(Film film1, Film film2, Film film3, Film film4, Film film5) {
        this.film1 = film1;
        this.film2 = film2;
        this.film3 = film3;
        this.film4 = film4;
        this.film5 = film5;
        this.filmek = filmek;
    }

    public int filmekSzama(){
        return filmek.length;
    }

    public String legmagasabbErtekelesuFilm(){
        double maxErtekeles = filmek[0].getErtekeles();
        int maxErtekelesId = 0;

        for (int i = 1; i < filmek.length; i++) {
            if(maxErtekeles < filmek[i].getErtekeles()) {
                maxErtekeles = filmek[i].getErtekeles();
                maxErtekelesId = i;
            }
        }

        return filmek[maxErtekelesId].getCim();
    }

    public String[] adottEvFilmjei(int ev) {
        String[] adottEvFilmjei = new String[];

        for (int i = 0; i < filmek.length; i++) {
            if(filmek[i].getMegjelenesi_ev() == ev) {
                adottEvFilmjei.add(filmek[i].getCim());
            }
        }

        return adottEvFilmjei;
    }

    public String[] filmekSzureseErtekelesAlapjan(int minimumErtekeles) {
        String minimumFelettErtekeltFilmek[] = new String[];

        for (int i = 0; i < filmek.length; i++) {
            if(filmek[i].getErtekeles() > minimumErtekeles) {
                minimumFelettErtekeltFilmek.add(filmek[i].getCim());
            }
        }

        return minimumFelettErtekeltFilmek;
    }
}
