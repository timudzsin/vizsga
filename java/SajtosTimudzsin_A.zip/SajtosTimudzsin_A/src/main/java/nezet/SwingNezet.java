package nezet;

import modell.Modell;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class SwingNezet extends JFrame {
    public SwingNezet(Modell odell) {
        setTitle("Filmgyűjtemény");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);





        // Kilépés megerősítése
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int answer = JOptionPane.showConfirmDialog(
                        SwingNezet.this,
                        "Biztosan ki szeretnél lépni?",
                        "Kilépés megerősítése",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

                if (answer == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

    }
}
